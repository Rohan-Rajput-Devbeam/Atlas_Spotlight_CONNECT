import * as React from 'react';
import './DocModal.css';
import 'bootstrap/dist/css/bootstrap.css';
import { SPService } from '../Service/SPServices';
export declare class DescriptionModal extends React.Component<any, any> {
    SPService: SPService;
    closeModal: (e: any) => void;
    constructor(props: any);
    componentDidMount(): void;
    getCurrentUser_1(): Promise<void>;
    toggleFavorites_1(item: any, isFavorite: any, listID: any): Promise<void>;
    addFeatured_1(docID: any, featured: any): Promise<void>;
    getAllDocs2_1(brandID: any): Promise<void>;
    render(): JSX.Element;
}
//# sourceMappingURL=DescriptionModal.d.ts.map