import * as React from 'react';
import { IAtlasSpotlightConnectProps } from './IAtlasSpotlightConnectProps';
import { SPService } from '../Service/SPServices';
import "isomorphic-fetch";
export interface IAtlasSpotlightConnectState {
    showDescriptionModal: boolean;
    currentDataset: any;
    brandID: any;
    currUserGroups: any;
    displayFlag: boolean;
    currentUserEmail: string;
    cuurentUserID: any;
    currentUserFavItems: any;
    favDocMapping: any;
    favListIDs: any;
    docItems: any;
}
export default class AtlasSpotlightConnect extends React.Component<IAtlasSpotlightConnectProps, IAtlasSpotlightConnectState> {
    SPService: SPService;
    constructor(props: IAtlasSpotlightConnectProps);
    openModal(id: number): void;
    closeModal(): void;
    componentDidUpdate(): void;
    getFavoriteListItems(): Promise<void>;
    checkFavDocuments(): Promise<void>;
    toggleFavorites(item: any, isFavorite: any, listID: any): Promise<void>;
    addFeatured(docID: any, featured: any): Promise<void>;
    getAllDocs2(brandID: any): Promise<void>;
    componentDidMount(): Promise<void>;
    getUserGroups2(): Promise<void>;
    categorizeGroups(): Promise<void>;
    getCurrentUser(): Promise<void>;
    render(): React.ReactElement<IAtlasSpotlightConnectProps>;
}
//# sourceMappingURL=AtlasSpotlightConnect.d.ts.map