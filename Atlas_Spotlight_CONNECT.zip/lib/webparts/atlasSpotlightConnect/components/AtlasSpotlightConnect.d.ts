import * as React from 'react';
import { IAtlasSpotlightConnectProps } from './IAtlasSpotlightConnectProps';
import { SPService } from '../Service/SPServices';
export interface IAtlasSpotlightConnectState {
    showDescriptionModal: boolean;
    currentDataset: any;
    brandID: any;
    currUserGroups: any;
    displayFlag: boolean;
}
export default class AtlasSpotlightConnect extends React.Component<IAtlasSpotlightConnectProps, IAtlasSpotlightConnectState> {
    SPService: SPService;
    constructor(props: IAtlasSpotlightConnectProps);
    openModal(id: number): void;
    closeModal(): void;
    componentDidUpdate(): void;
    componentDidMount(): Promise<void>;
    getAllDocs2(brandID: any): Promise<void>;
    getUserGroups2(): Promise<void>;
    categorizeGroups(): void;
    render(): React.ReactElement<IAtlasSpotlightConnectProps>;
}
//# sourceMappingURL=AtlasSpotlightConnect.d.ts.map