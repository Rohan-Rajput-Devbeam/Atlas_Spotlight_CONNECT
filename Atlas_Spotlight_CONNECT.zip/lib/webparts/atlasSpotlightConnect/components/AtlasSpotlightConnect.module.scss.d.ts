declare const styles: {
    MainContainer: string;
    callToAction: string;
    arrow: string;
    containermain: string;
    modalHeader: string;
    addDocuments: string;
    docCard: string;
    docCardHeader: string;
    modalXl: string;
};
export default styles;
//# sourceMappingURL=AtlasSpotlightConnect.module.scss.d.ts.map