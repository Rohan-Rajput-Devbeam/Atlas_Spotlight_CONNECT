import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IPickerTerms } from "@pnp/spfx-property-controls/lib/PropertyFieldEnterpriseTermPicker";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/folders";
export interface IAtlasSpotlightConnectWebPartProps {
    titleText: string;
    filePickerResult: any;
    description: string;
    hyperlink: any;
    terms: IPickerTerms;
    linkOrMetadata: any;
    people: any;
}
export default class AtlasSpotlightConnectWebPart extends BaseClientSideWebPart<IAtlasSpotlightConnectWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=AtlasSpotlightConnectWebPart.d.ts.map