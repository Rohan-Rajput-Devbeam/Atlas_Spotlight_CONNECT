import { WebPartContext } from "@microsoft/sp-webpart-base";
import "isomorphic-fetch";
export declare class SPService {
    private context;
    state: {
        allItems: any[];
        currPageUrl: string;
        currUserGroups: any[];
        checkPermission: boolean;
    };
    abc: any[];
    rackName: string;
    people: [];
    authuser: boolean;
    checkPermission: boolean;
    callSomething(items: any[]): any[];
    constructor(context: WebPartContext);
    getTermStore(): void;
    getUserGroups(): Promise<void>;
    checkUseFullname(userArray: any): boolean;
    getAllDocsCAML(selectedBrand: any, selectedTerm: any, lowerRange: any, upperRange: any): Promise<any>;
    getFavoriteListItems(curentUserID: any): Promise<any>;
    getFavoriteListItems2(curentUserID: any): Promise<any>;
    getCurrentUser(): Promise<import("@pnp/sp/site-users/types").ISiteUserInfo>;
    addFeatured(docId: any): Promise<void>;
    removedFeatured(docId: any): Promise<void>;
    s: any;
    getFavoriteListItems_1(curentUserID: any): Promise<any>;
    getFavoriteListItems2_1(curentUserID: any): Promise<any>;
    toggleFavorites_1(item: any, isFavorite: any, listID: any): Promise<void>;
    getCurrentUser_1(): Promise<import("@pnp/sp/site-users/types").ISiteUserInfo>;
    addFeatured_1(docId: any): Promise<void>;
    removedFeatured_1(docId: any): Promise<void>;
}
//# sourceMappingURL=SPServices.d.ts.map