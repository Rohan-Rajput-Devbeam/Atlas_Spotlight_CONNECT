import { WebPartContext } from "@microsoft/sp-webpart-base";
import "@pnp/sp/webs";
import "@pnp/sp/folders";
export declare class SPService {
    private context;
    state: {
        allItems: any[];
        currPageUrl: string;
        currUserGroups: any[];
        checkPermission: boolean;
    };
    abc: any[];
    rackName: string;
    people: [];
    authuser: boolean;
    checkPermission: boolean;
    callSomething(items: any[]): any[];
    constructor(context: WebPartContext);
    getUserGroups(): Promise<any>;
    checkUseFullname(userArray: any): boolean;
    getAllDocs(selectedBrand: any, selectedTerm: any): Promise<any>;
}
//# sourceMappingURL=SPServices.d.ts.map