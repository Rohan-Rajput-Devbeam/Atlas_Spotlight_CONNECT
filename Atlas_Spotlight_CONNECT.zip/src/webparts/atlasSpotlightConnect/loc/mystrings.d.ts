declare interface IAtlasSpotlightConnectWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'AtlasSpotlightConnectWebPartStrings' {
  const strings: IAtlasSpotlightConnectWebPartStrings;
  export = strings;
}
