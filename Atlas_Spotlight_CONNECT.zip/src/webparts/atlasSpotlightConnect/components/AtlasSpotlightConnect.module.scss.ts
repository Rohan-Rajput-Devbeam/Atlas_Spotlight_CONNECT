/* tslint:disable */
require("./AtlasSpotlightConnect.module.css");
const styles = {
  downloadBut1: 'downloadBut1_eeb8dc07',
  MainContainer: 'MainContainer_eeb8dc07',
  callToAction: 'callToAction_eeb8dc07',
  arrow: 'arrow_eeb8dc07',
  containermain: 'containermain_eeb8dc07',
  modalHeader: 'modalHeader_eeb8dc07',
  addDocuments: 'addDocuments_eeb8dc07',
  docCard: 'docCard_eeb8dc07',
  docCardHeader: 'docCardHeader_eeb8dc07',
  modalXl: 'modalXl_eeb8dc07'
};

export default styles;
/* tslint:enable */