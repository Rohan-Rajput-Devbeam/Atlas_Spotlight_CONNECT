/* tslint:disable */
require("./AtlasSpotlightConnect.module.css");
const styles = {
  MainContainer: 'MainContainer_ffba8ec6',
  callToAction: 'callToAction_ffba8ec6',
  arrow: 'arrow_ffba8ec6',
  containermain: 'containermain_ffba8ec6',
  modalHeader: 'modalHeader_ffba8ec6',
  addDocuments: 'addDocuments_ffba8ec6',
  docCard: 'docCard_ffba8ec6',
  docCardHeader: 'docCardHeader_ffba8ec6',
  modalXl: 'modalXl_ffba8ec6'
};

export default styles;
/* tslint:enable */